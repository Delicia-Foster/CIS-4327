﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.IO;
using Website1.Data;

    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<ApplicationDbContext>
    {
        public ApplicationDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();

            // Make sure this connection string is correct
            optionsBuilder.UseMySql("server=localhost;database=Bartender;user=root;password=rootpassword;",
                new MySqlServerVersion(new Version(8, 0, 31)));

            return new ApplicationDbContext(optionsBuilder.Options);
        }
    }

