﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Website1.Models;

namespace Website1.Data
{
	public class ApplicationDbContext : DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options){}

		public DbSet<Orders> Orders { get; set; }
		public DbSet<Drink> Drink { get; set; }
		public DbSet<Cart> Cart { get; set; }
	}
}

