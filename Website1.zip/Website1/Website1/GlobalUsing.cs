﻿global using Microsoft.EntityFrameworkCore;
