﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Website1.Models;
using Website1.Data;

namespace Website1.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly ApplicationDbContext _context;
    public int _orderId;

    private static List<Drink> cartItems = new List<Drink>();

    public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
    {
        _logger = logger;
        _context = context;
        _orderId = 1;
    }

    public async Task<IActionResult> Index()
    {
        var drinks = await _context.Drink.ToListAsync();

        if (drinks.Any())
        {
            // Remove all records if the table is not empty
            _context.Drink.RemoveRange(drinks);
            await _context.SaveChangesAsync();
        }

        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult Account()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Login(Account account)
    {
        const string validUsername = "admin";
        const string validPassword = "password";

        if (account.Username == validUsername && account.Password == validPassword)
        {
            return View("Queue");
        }
        else
        {
            ViewData["ErrorMessage"] = "Invalid username or password. Please try again.";
            return View("Account");
        }
    }

    public async Task<IActionResult> Menu()
    {
        var whiskey = new Drink { Id=1, DrinkName = "Whiskey", DrinkImage = "../images/whisky.png", Description = "Warm, rich flavors and a hint of smoke. The perfect companion for making any moment legendary" };
        var mojito = new Drink { Id = 2, DrinkName = "Mojito", DrinkImage = "../images/mojito.png", Description = "A refreshing party starter with zesty lime, cool mint, and a splash of rum. A mini tropical getaway in every sip" };
        var martini = new Drink { Id = 3, DrinkName = "Martini", DrinkImage = "../images/martini.png", Description = "Stylish and sophisticated. The go-to for an elegant night out" };
        var aperol = new Drink { Id = 4, DrinkName = "Aperol", DrinkImage = "../images/aperol.png", Description = "Bright, bubbly, and bursting with zest! A celebration in a glass, perfect for toasting to good times" };
        var gant = new Drink { Id = 5, DrinkName = "Gin & Tonic", DrinkImage = "../images/gandt.png", Description = "Crisp, cool, and always refreshing. A timeless combo for a laid-back, yet invigorating, sip" };

        _context.Drink.AddRange(new[] { whiskey, mojito, martini, aperol, gant });
        await _context.SaveChangesAsync();
        var drinks = await _context.Drink.ToListAsync();

        return View(drinks);
    }

    public async Task<IActionResult> Queue()
    {
        var queue = await _context.Orders.ToListAsync();
        return View(queue);
    }

    public IActionResult Cart(int drinkID)
    {
        var drinkToAdd = _context.Drink.FirstOrDefault(c => c.Id == drinkID);
        cartItems.Add(drinkToAdd);

        return View(cartItems);
    }

    public IActionResult Payment()
    {

        return View();
    }

    public async Task<IActionResult> CheckOut(Customer customer)
    {
        var custName = customer.Name;
        string drinks = "";

        foreach (var item in cartItems)
        {
            drinks += item.DrinkName;
        }

        var order = new Orders { Cust_name = custName, Drinks = drinks };
        _context.Orders.Add(order);

        await _context.SaveChangesAsync();
        cartItems.Clear();
        return RedirectToAction("Index");
    }

    public void Send4Pickup(int id)
    {
        var order = _context.Orders.Find(id); // Find the entity by its primary key
        if (order != null)
        {
            _context.Orders.Remove(order); // Mark the entity for deletion
            _context.SaveChanges(); // Persist changes to the database
        }
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

