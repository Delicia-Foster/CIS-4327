﻿using System;
namespace Website1.Models
{
	public class Orders
	{
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Cust_name { get; set; }
		public string Drinks { get; set; }
	}
}

