﻿using System;
namespace Website1.Models
{
	public class Drink
	{
            public string DrinkName { get; set; }
            public int Id { get; set; }
            public string DrinkImage { get; set; }
            public string Description { get; set; }
    }
}

