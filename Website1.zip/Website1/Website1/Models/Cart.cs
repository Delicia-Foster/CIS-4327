﻿using System;
namespace Website1.Models
{
	public class Cart
	{
        public string Id { get; set; }
        public string Name { get; set; }
        public string Quantity { get; set; }
    }
}

