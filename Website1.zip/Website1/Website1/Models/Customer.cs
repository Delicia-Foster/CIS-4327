﻿using System;
namespace Website1.Models
{
	public class Customer
	{
		public string Name { get; set; }
        public int Id { get; set; }
    }
}

